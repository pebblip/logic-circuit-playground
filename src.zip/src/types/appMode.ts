export type AppMode = '学習モード' | 'フリーモード' | 'パズルモード' | 'ギャラリーモード';

export type ViewMode = 'normal' | 'custom-gate-preview';
